const { saudacao, formatarData } = require('./utils');
const config = require('./config');
console.log(saudacao('Professor'));
console.log(`Data de hoje: ${formatarData()}`);
console.log(`Rodando o projeto: ${config.nomeProjeto}`);
console.log(`Porta configurada: ${config.porta}`);


const express = require('express');
const app = express();
const PORTA = 3000;
app.listen(PORTA, () => {
console.log(`Servidor rodando em http://localhost:${PORTA}`);
});


const express = require('express');
const app = express();
const PORTA = 3000;
app.get('/', (req, res) => {
res.send('Bem-vindo ao Sistema de Gerenciamento de Biblioteca!');
});
app.get('/sobre', (req, res) => {
res.send('Este é um projeto acadêmico para gerenciar livros, usuários e empréstimos.');
});
app.get('/contato', (req, res) => {
res.send('Fale com a biblioteca pelo e-mail: contato@biblioteca.com');
});
app.listen(PORTA, () => {
console.log(`Servidor rodando em http://localhost:${PORTA}`);
});

app.get('/sobre', (req, res) => {
res.json({
projeto: 'Sistema de Gerenciamento de Biblioteca',
versao: '1.0.0',
autor: 'Turma de Node.js',
});app.use((req, res, next) => {
const agora = new Date().toLocaleTimeString('pt-BR');
console.log(`[${agora}] ${req.method} ${req.url}`);
next(); // repassa a requisição para a próxima rota/middleware
});
});

app.use((req, res, next) => {
const agora = new Date().toLocaleTimeString('pt-BR');
console.log(`[${agora}] ${req.method} ${req.url}`);
next(); // repassa a requisição para a próxima rota/middleware
});
